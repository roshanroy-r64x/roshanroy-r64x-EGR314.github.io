from machine import Pin, I2C, UART
import ssd1306
import time

i2c = I2C(0, scl=Pin(22), sda=Pin(21))
oled = ssd1306.SSD1306_I2C(128, 64, i2c)

uart = UART(1, baudrate=9600, tx=Pin(17), rx=Pin(16))

button_up = Pin(19, Pin.IN, Pin.PULL_UP)
button_down = Pin(23, Pin.IN, Pin.PULL_UP)
button_led_on = Pin(5, Pin.IN, Pin.PULL_UP)
button_led_off = Pin(18, Pin.IN, Pin.PULL_UP)

led = Pin(2, Pin.OUT)
led.value(0)

led_state = "OFF"
motor_line1 = "WAITING WIFI"
motor_line2 = ""
wifi_ok = False
uart_buffer = ""

def draw_screen():
    oled.fill(0)
    oled.text("LED STATE: " + led_state, 0, 0)
    oled.text(motor_line1, 0, 28)
    oled.text(motor_line2, 0, 40)
    oled.show()

def show_message(line1, line2=""):
    oled.fill(0)
    oled.text(line1, 0, 20)
    oled.text(line2, 0, 35)
    oled.show()

def send_message(data):
    msg = "AZRQ" + data + "YB"
    uart.write(msg)
    print("Sent:", msg)

def handle_uart_message(msg):
    global wifi_ok, motor_line1, motor_line2

    print("Received:", msg)

    if msg == "AZDRYESYB":
        wifi_ok = True
        motor_line1 = "WIFI CONNECTED"
        motor_line2 = "READY"
        draw_screen()

    elif "AZDRNOYB" in msg:
        wifi_ok = True
        motor_line1 = "WIFI NOT"
        motor_line2 = "CONNECTED"
        draw_screen()

    elif "ERROR" in msg:
        wifi_ok = False
        motor_line1 = "ERROR"
        motor_line2 = ""
        draw_screen()

    else:
        wifi_ok = False
        show_message("INVALID", "MESSAGE")

def check_uart():
    global uart_buffer

    if uart.any():
        data = uart.read()

        if data:
            try:
                uart_buffer += data.decode()
            except:
                uart_buffer = ""
                show_message("UART DECODE", "ERROR")
                return

            while "YB" in uart_buffer:
                end_index = uart_buffer.find("YB") + 2
                msg = uart_buffer[:end_index]
                uart_buffer = uart_buffer[end_index:]
                handle_uart_message(msg)

draw_screen()

last_up = 1
last_down = 1
last_led_on = 1
last_led_off = 1

while True:
    check_uart()

    up_now = button_up.value()
    down_now = button_down.value()
    led_on_now = button_led_on.value()
    led_off_now = button_led_off.value()

    if up_now == 0 and last_up == 1:
        if wifi_ok:
            motor_line1 = "MOTOR DIRECTION:"
            motor_line2 = "FORWARD"
            draw_screen()
            print("up")
            send_message("forward")
        else:
            show_message("WIFI REQUIRED", "CANNOT RUN")

    if down_now == 0 and last_down == 1:
        if wifi_ok:
            motor_line1 = "MOTOR DIRECTION:"
            motor_line2 = "REVERSE"
            draw_screen()
            print("down")
            send_message("reverse")
        else:
            show_message("WIFI REQUIRED", "CANNOT RUN")

    if led_on_now == 0 and last_led_on == 1:
        if wifi_ok:
            led.value(1)
            led_state = "ON"
            draw_screen()
            print("LED ON")
        else:
            show_message("WIFI REQUIRED", "NO LED")

    if led_off_now == 0 and last_led_off == 1:
        if wifi_ok:
            led.value(0)
            led_state = "OFF"
            draw_screen()
            print("LED OFF")
        else:
            show_message("WIFI REQUIRED", "NO LED")

    last_up = up_now
    last_down = down_now
    last_led_on = led_on_now
    last_led_off = led_off_now

    time.sleep_ms(20)